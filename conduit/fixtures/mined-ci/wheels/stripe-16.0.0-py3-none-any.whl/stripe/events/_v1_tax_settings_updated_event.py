# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from stripe._stripe_object import StripeObject
from stripe._util import get_api_mode
from stripe.v2.core._event import (
    Event,
    EventNotification,
    RelatedSingletonObject,
)
from typing import Any, Dict, cast
from typing_extensions import Literal, TYPE_CHECKING, override

if TYPE_CHECKING:
    from stripe._stripe_client import StripeClient
    from stripe.tax._settings import Settings


class V1TaxSettingsUpdatedEventNotification(EventNotification):
    LOOKUP_TYPE = "v1.tax.settings.updated"
    type: Literal["v1.tax.settings.updated"]
    related_object: RelatedSingletonObject

    def __init__(
        self, parsed_body: Dict[str, Any], client: "StripeClient"
    ) -> None:
        super().__init__(
            parsed_body,
            client,
        )
        self.related_object = RelatedSingletonObject(
            parsed_body["related_object"],
        )

    @override
    def fetch_event(self) -> "V1TaxSettingsUpdatedEvent":
        return cast(
            "V1TaxSettingsUpdatedEvent",
            super().fetch_event(),
        )

    def fetch_related_object(self) -> "Settings":
        response = self._client.raw_request(
            "get",
            self.related_object.url,
            stripe_context=self.context,
            headers={"Stripe-Request-Trigger": f"event={self.id}"},
            usage=["fetch_related_object"],
        )
        return cast(
            "Settings",
            self._client.deserialize(
                response,
                api_mode=get_api_mode(self.related_object.url),
            ),
        )

    @override
    async def fetch_event_async(self) -> "V1TaxSettingsUpdatedEvent":
        return cast(
            "V1TaxSettingsUpdatedEvent",
            await super().fetch_event_async(),
        )

    async def fetch_related_object_async(self) -> "Settings":
        response = await self._client.raw_request_async(
            "get",
            self.related_object.url,
            stripe_context=self.context,
            headers={"Stripe-Request-Trigger": f"event={self.id}"},
            usage=["fetch_related_object"],
        )
        return cast(
            "Settings",
            self._client.deserialize(
                response,
                api_mode=get_api_mode(self.related_object.url),
            ),
        )


class V1TaxSettingsUpdatedEvent(Event):
    LOOKUP_TYPE = "v1.tax.settings.updated"
    type: Literal["v1.tax.settings.updated"]

    class RelatedSingletonObject(StripeObject):
        type: str
        """
        Type of the object relevant to the event.
        """
        url: str
        """
        URL to retrieve the resource.
        """

    related_object: RelatedSingletonObject
    """
    Object containing the reference to API resource relevant to the event
    """

    def fetch_related_object(self) -> "Settings":
        """
        Retrieves the related object from the API. Makes an API request on every call.
        """
        return cast(
            "Settings",
            self._requestor.request(
                "get",
                self.related_object.url,
                base_address="api",
                options={
                    "stripe_context": self.context,
                    "headers": {"Stripe-Request-Trigger": f"event={self.id}"},
                },
            ),
        )
