"""Synchronous client implementations."""
