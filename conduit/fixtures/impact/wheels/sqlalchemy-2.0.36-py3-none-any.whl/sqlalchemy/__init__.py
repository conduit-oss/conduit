"""Trimmed SQLAlchemy 2.0 surface for offline impact tests."""
