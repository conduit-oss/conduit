"""Trimmed ORM surface. Query.get is gone. Session.query is deprecated."""


class Query:
    def filter(self, *criterion):
        return self


class Session:
    def query(self, *entities):
        """deprecated: legacy query API. Use Session.get."""
        return Query()

    def get(self, entity, ident):
        """Return an instance by primary key."""
        return ident
