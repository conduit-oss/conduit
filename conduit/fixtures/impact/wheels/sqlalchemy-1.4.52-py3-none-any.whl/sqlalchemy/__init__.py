"""Trimmed SQLAlchemy 1.4 surface for offline impact tests."""
