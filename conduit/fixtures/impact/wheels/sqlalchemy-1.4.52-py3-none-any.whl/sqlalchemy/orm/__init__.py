"""Trimmed ORM surface. Query.get is the 1.4 lookup."""


class Query:
    def get(self, ident):
        """Return an instance by primary key."""
        return ident

    def filter(self, *criterion):
        return self


class Session:
    def query(self, *entities):
        """Build a query."""
        return Query()
