"""Recorded external API client, version 1.0.0."""


class Client:
    def complete(self, prompt: str, max_tokens: int = 16):
        """Create a completion."""
        return {"text": prompt, "max_tokens": max_tokens}
