"""Recorded external API client, version 1.2.0."""

import http.client


class Client:
    def __init__(self) -> None:
        self._conn = http.client.HTTPSConnection("api.acme.invalid")


    def complete(self, prompt: str, max_completion_tokens: int = 16):
        """Create a completion."""
        self._conn.request("POST", "/v1/complete")
        return {"text": prompt, "max_completion_tokens": max_completion_tokens}
