"""Recorded external API client, version 1.2.0."""


class Client:
    def complete(self, prompt: str, max_completion_tokens: int = 16):
        """Create a completion."""
        return {"text": prompt, "max_completion_tokens": max_completion_tokens}
