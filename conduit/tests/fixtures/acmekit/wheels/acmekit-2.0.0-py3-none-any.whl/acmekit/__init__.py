"""Invented SDK stub for impact tests. Version 2.0.0."""

class Client:
    def generate(self, prompt: str) -> str:
        """Renamed from complete."""
        return prompt
