"""Invented SDK stub for impact tests. Version 1.0.0."""

class Client:
    def complete(self, prompt: str) -> str:
        """Create a completion (removed in 2.x)."""
        return prompt
